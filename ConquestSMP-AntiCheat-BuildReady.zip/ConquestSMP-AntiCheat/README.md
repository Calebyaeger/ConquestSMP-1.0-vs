# Conquest SMP Anti-Cheat

**Version:** 1.0.0  
**Target:** Paper 1.21.11  
**Java:** 21  
**Build:** Maven

A modular, evidence-first server-side anti-cheat. It records check results to SQLite and sends configurable staff alerts. Punishments are staff-reviewed by default; no permanent bans are ever issued by this plugin.

## Build

Install JDK 21 and Maven 3.9+, then run from this folder:

```bash
mvn clean package
```

The shaded plugin artifact is `target/ConquestSMP-AntiCheat.jar`. Paper API is a provided dependency; SQLite JDBC is bundled and relocated into the plugin jar.

## Install

1. Stop the Paper 1.21.11 server.
2. Copy `target/ConquestSMP-AntiCheat.jar` into the server's `plugins/` folder.
3. Start the server once to generate `plugins/ConquestSMP-AntiCheat/config.yml` and the SQLite database.
4. Review `config.yml`, especially detection sensitivities and alert settings.
5. Grant trusted staff `conquestac.staff`, `conquestac.alerts`, `conquestac.check`, `conquestac.history`, `conquestac.xray`, and `conquestac.reload` as appropriate.
6. Restart or run `/cac reload` after configuration changes.

## Commands

- `/cac help`
- `/cac alerts` — toggle personal alerts for the current session
- `/cac check <player>` — current-session violation level and UUID
- `/cac history <player>` — latest stored evidence
- `/cac xray <player>` — stored X-ray evidence entries
- `/cac reload`
- `/cac info`
- `/cac punish <player> <warn|kick|tempban>` — explicit staff-reviewed action

The `punish` command is staff-only and requires the target to be online. Temporary-ban duration is configured by `punishments.temporary-ban-minutes`.

## Permissions

| Permission | Default | Purpose |
|---|---|---|
| `conquestac.staff` | op | Main staff command / manual punishments |
| `conquestac.alerts` | op | Receive live alerts and toggle personal alerts |
| `conquestac.check` | op | Inspect current player profile |
| `conquestac.history` | op | Read evidence history |
| `conquestac.xray` | op | Read mining-analysis history |
| `conquestac.reload` | op | Reload config |

## Detection coverage and limitations

This plugin uses server-observable heuristics, not client inspection. It is not a substitute for human review or a packet-level anti-cheat. Sensitivities should be calibrated on a staging server before production use.

- **X-ray:** rolling ore-to-block ratio. It cannot prove X-ray; world seed, mining strategy, caves, and resource packs can affect the ratio. The current counter is in-memory and resets when the server restarts; flagged evidence persists.
- **Combat / Reach:** measures eye-to-target distance on player melee events. It does not reconstruct historical hitboxes or fully compensate for latency; the threshold is configurable.
- **AutoClicker:** estimates hit frequency from combat hit events, not raw client clicks. It is an indicator only and is not a precise CPS meter.
- **KillAura:** rapid changes between damaged entities are flagged as a weak signal. Legitimate multi-target combat can trigger it.
- **Aim Assist:** samples yaw-change variance over movement events. This is a weak statistical signal and should never be used alone for punishment.
- **Speed / Fly / BunnyHop:** conservative movement heuristics. They skip common exemptions such as flight permission, Elytra, vehicles, swimming, liquids, Levitation, and Slow Falling. Server lag, velocity, custom abilities, and unusual terrain can still affect results.
- **Anti-Knockback:** checks for low displacement shortly after a velocity event. Walls, collisions, low-strength hits, and latency can create false positives.
- **NoFall:** only flags the narrow case where a qualifying fall-distance event reports effectively zero final damage. It does not claim to detect every NoFall implementation.
- **FastBreak:** compares BlockDamageEvent-to-break elapsed time. It does not model each block's hardness, tool, enchantments, haste, or server tick timing, so use a conservative threshold.
- **Scaffold:** counts repeated blocks placed at/below the player's feet. Bridging styles and lag can create false positives.
- **Suspicious placement:** high placement event rate, not a proof of automation.
- **Inventory:** counts inventory click events per second. It does not identify every inventory exploit or malformed packet; packet-level exploit coverage requires deeper protocol integration.

Some checks are intentionally heuristic because Bukkit/Paper's public event API does not expose enough information to prove the named cheat. Review evidence and context before taking action. The plugin does not automatically issue permanent bans.

## Database and webhook

SQLite is stored at `plugins/ConquestSMP-AntiCheat/violations.db` by default. Database writes and history reads run on a dedicated worker thread. Webhook notifications use Java's asynchronous HTTP client. Set `alerts.webhook.enabled: true` and provide a Discord webhook URL privately in `config.yml`; do not publish it.

## Operational recommendations

- Back up `plugins/ConquestSMP-AntiCheat/violations.db` before server migrations.
- Test with normal players, high-ping players, potion effects, custom items, and server abilities.
- Keep `punishments.staff-review-required: true` until false-positive rates are understood.
- Do not treat a single alert as proof of cheating.
