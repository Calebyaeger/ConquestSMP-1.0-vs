package com.conquest.anticheat.db;

import com.conquest.anticheat.model.Violation;
import java.io.File;
import java.sql.*;
import java.util.*;
import java.util.concurrent.*;

public final class ViolationDatabase implements AutoCloseable {
    private final String url;
    private final ExecutorService worker = Executors.newSingleThreadExecutor(r -> { Thread t = new Thread(r, "ConquestAC-Database"); t.setDaemon(true); return t; });
    public ViolationDatabase(File file) { this.url = "jdbc:sqlite:" + file.getAbsolutePath(); }
    public void initialize() throws SQLException {
        try (Connection c = DriverManager.getConnection(url); Statement s = c.createStatement()) {
            s.executeUpdate("CREATE TABLE IF NOT EXISTS violations (id INTEGER PRIMARY KEY AUTOINCREMENT, uuid TEXT NOT NULL, name TEXT NOT NULL, check_name TEXT NOT NULL, amount REAL NOT NULL, evidence TEXT NOT NULL, created_at TEXT NOT NULL)");
            s.executeUpdate("CREATE INDEX IF NOT EXISTS idx_violations_uuid ON violations(uuid)");
        }
    }
    public void insert(Violation v) { worker.submit(() -> { try (Connection c=DriverManager.getConnection(url); PreparedStatement p=c.prepareStatement("INSERT INTO violations(uuid,name,check_name,amount,evidence,created_at) VALUES(?,?,?,?,?,?)")) { p.setString(1,v.playerId().toString());p.setString(2,v.playerName());p.setString(3,v.check());p.setDouble(4,v.amount());p.setString(5,v.evidence());p.setString(6,v.time().toString());p.executeUpdate(); } catch(SQLException e){e.printStackTrace();} }); }
    public CompletableFuture<List<String>> history(UUID uuid, int limit) {
        return CompletableFuture.supplyAsync(() -> { List<String> rows=new ArrayList<>(); try(Connection c=DriverManager.getConnection(url);PreparedStatement p=c.prepareStatement("SELECT check_name,amount,evidence,created_at FROM violations WHERE uuid=? ORDER BY id DESC LIMIT ?")){p.setString(1,uuid.toString());p.setInt(2,limit);try(ResultSet r=p.executeQuery()){while(r.next()) rows.add(r.getString(4)+" | "+r.getString(1)+" +"+r.getDouble(2)+" | "+r.getString(3));}}catch(SQLException e){rows.add("Database error: "+e.getMessage());}return rows;},worker);
    }
    @Override public void close(){worker.shutdown();}
}
