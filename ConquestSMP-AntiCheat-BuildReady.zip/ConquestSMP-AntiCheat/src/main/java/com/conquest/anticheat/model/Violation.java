package com.conquest.anticheat.model;

import java.time.Instant;
import java.util.UUID;

public record Violation(UUID playerId, String playerName, String check, double amount, String evidence, Instant time) { }
