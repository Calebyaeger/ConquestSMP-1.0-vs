package com.conquest.anticheat.util;

import java.net.URI;
import java.net.http.*;
import java.time.Duration;

public final class Webhook {
    private static final HttpClient CLIENT=HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(4)).build();
    private Webhook(){}
    public static void send(String url,String message){ if(url==null||url.isBlank()) return; String safe=message.replace("\\","\\\\").replace("\"","\\\"").replace("\n"," "); String body="{\"content\":\""+safe+"\"}"; HttpRequest req=HttpRequest.newBuilder(URI.create(url)).timeout(Duration.ofSeconds(5)).header("Content-Type","application/json").POST(HttpRequest.BodyPublishers.ofString(body)).build(); CLIENT.sendAsync(req,HttpResponse.BodyHandlers.discarding()).exceptionally(ex->null); }
}
