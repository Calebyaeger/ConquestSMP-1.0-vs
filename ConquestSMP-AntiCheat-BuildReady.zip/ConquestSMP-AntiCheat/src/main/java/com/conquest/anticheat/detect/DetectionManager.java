package com.conquest.anticheat.detect;

import com.conquest.anticheat.ConquestAntiCheat;
import com.conquest.anticheat.model.Violation;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.block.*;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.*;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Vector;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public final class DetectionManager implements Listener {
    private final ConquestAntiCheat plugin;
    private final Map<UUID,Long> joined=new ConcurrentHashMap<>(), lastMove=new ConcurrentHashMap<>(), lastBreak=new ConcurrentHashMap<>(), lastPlace=new ConcurrentHashMap<>(), lastClick=new ConcurrentHashMap<>();
    private final Map<UUID,Integer> airTicks=new ConcurrentHashMap<>(), jumpStreak=new ConcurrentHashMap<>(), inventoryClicks=new ConcurrentHashMap<>(), combatHits=new ConcurrentHashMap<>(), placeCount=new ConcurrentHashMap<>(), underPlaces=new ConcurrentHashMap<>();
    private final Map<UUID,Long> placeWindow=new ConcurrentHashMap<>(), clickWindow=new ConcurrentHashMap<>(), hitWindow=new ConcurrentHashMap<>(), oreWindow=new ConcurrentHashMap<>();
    private final Map<UUID,Integer> mined=new ConcurrentHashMap<>(), ores=new ConcurrentHashMap<>(), targetSwitches=new ConcurrentHashMap<>();
    private final Map<UUID,UUID> lastTarget=new ConcurrentHashMap<>();
    private final Map<UUID,Double> yawChanges=new ConcurrentHashMap<>(), yawSquared=new ConcurrentHashMap<>();
    private final Map<UUID,Integer> aimSamples=new ConcurrentHashMap<>(), cpsSamples=new ConcurrentHashMap<>();
    private final Map<UUID,Long> velocityAt=new ConcurrentHashMap<>();
    private final Map<UUID,Location> velocityOrigin=new ConcurrentHashMap<>();
    public DetectionManager(ConquestAntiCheat plugin){this.plugin=plugin;}
    private boolean on(String path){return plugin.getConfig().getBoolean(path,true);}
    private boolean active(Player p){return System.currentTimeMillis()-joined.getOrDefault(p.getUniqueId(),0L)>plugin.getConfig().getLong("settings.join-grace-seconds",8)*1000L && p.getGameMode()!=GameMode.SPECTATOR;}
    private boolean exemptMovement(Player p){return p.isFlying()||p.isInsideVehicle()||p.isGliding()||p.isSwimming()||p.getLocation().getBlock().isLiquid()||p.getLocation().add(0,-1,0).getBlock().isLiquid()||p.hasPotionEffect(PotionEffectType.LEVITATION)||p.hasPotionEffect(PotionEffectType.SLOW_FALLING)||p.getAllowFlight();}
    private void flag(Player p,String check,double vl,String evidence){plugin.flag(p,check,vl,evidence);}

    @EventHandler public void join(PlayerJoinEvent e){joined.put(e.getPlayer().getUniqueId(),System.currentTimeMillis());}
    @EventHandler public void quit(PlayerQuitEvent e){UUID id=e.getPlayer().getUniqueId(); joined.remove(id);airTicks.remove(id);jumpStreak.remove(id);}

    // Movement heuristics are deliberately conservative and skip common legitimate movement modifiers.
    @EventHandler(ignoreCancelled=true,priority=EventPriority.MONITOR) public void move(PlayerMoveEvent e){Player p=e.getPlayer();if(!active(p)||e.getTo()==null||exemptMovement(p))return; if(!Objects.equals(e.getFrom().getWorld(),e.getTo().getWorld()))return;
        double dx=e.getTo().getX()-e.getFrom().getX(), dz=e.getTo().getZ()-e.getFrom().getZ(), horizontal=Math.hypot(dx,dz); long now=System.currentTimeMillis();
        if(horizontal>plugin.getConfig().getDouble("detections.movement.speed.max-horizontal-per-tick",.82)&&on("detections.movement.speed.enabled"))flag(p,"Speed",1.0,String.format(Locale.US,"horizontal delta=%.3f",horizontal));
        int airborneBefore=airTicks.getOrDefault(p.getUniqueId(),0);
        if(p.isOnGround()||!e.getTo().getBlock().isPassable())airTicks.put(p.getUniqueId(),0);else airTicks.merge(p.getUniqueId(),1,Integer::sum);
        if(on("detections.movement.fly.enabled")&&airTicks.getOrDefault(p.getUniqueId(),0)>plugin.getConfig().getInt("detections.movement.fly.max-airborne-ticks",50)&&Math.abs(e.getTo().getY()-e.getFrom().getY())<0.003)flag(p,"Fly",1.0,"prolonged near-level airborne movement");
        if(p.isOnGround()&&airborneBefore>=3)jumpStreak.merge(p.getUniqueId(),1,Integer::sum);
        if(on("detections.movement.bunnyhop.enabled")&&jumpStreak.getOrDefault(p.getUniqueId(),0)>=plugin.getConfig().getInt("detections.movement.bunnyhop.min-repeated-jumps",5)){flag(p,"BunnyHop",1.0,"repeated jump cadence; review movement context");jumpStreak.put(p.getUniqueId(),0);}
        float yaw=Math.abs(e.getTo().getYaw()-e.getFrom().getYaw());if(yaw>180)yaw=360-yaw;if(yaw>0.01){yawChanges.merge(p.getUniqueId(),(double)yaw,Double::sum);yawSquared.merge(p.getUniqueId(),(double)yaw*yaw,Double::sum);aimSamples.merge(p.getUniqueId(),1,Integer::sum);}
        if(on("detections.combat.aim-assist.enabled")&&aimSamples.getOrDefault(p.getUniqueId(),0)>=plugin.getConfig().getInt("detections.combat.aim-assist.min-samples",24)){int n=aimSamples.get(p.getUniqueId());double mean=yawChanges.getOrDefault(p.getUniqueId(),0d)/n;double variance=yawSquared.getOrDefault(p.getUniqueId(),0d)/n-mean*mean;if(variance<plugin.getConfig().getDouble("detections.combat.aim-assist.low-variance",.035)&&mean>0.2)flag(p,"AimAssist",0.5,"low yaw-change variance; weak signal");aimSamples.put(p.getUniqueId(),0);yawChanges.put(p.getUniqueId(),0d);yawSquared.put(p.getUniqueId(),0d);}
        // Delayed knockback response check; displacement is measured on the main thread.
        if(velocityAt.containsKey(p.getUniqueId())&&now-velocityAt.get(p.getUniqueId())>250&&now-velocityAt.get(p.getUniqueId())<900){Location origin=velocityOrigin.get(p.getUniqueId());if(origin!=null&&p.getWorld().equals(origin.getWorld())&&p.getVelocity().lengthSquared()<0.02&&p.getLocation().distanceSquared(origin)<0.015&&on("detections.movement.anti-knockback.enabled")){flag(p,"AntiKnockback",1.0,"little displacement after velocity event; review collision/ping");velocityAt.remove(p.getUniqueId());velocityOrigin.remove(p.getUniqueId());}}
    }
    @EventHandler public void velocity(PlayerVelocityEvent e){velocityAt.put(e.getPlayer().getUniqueId(),System.currentTimeMillis());velocityOrigin.put(e.getPlayer().getUniqueId(),e.getPlayer().getLocation().clone());}
    @EventHandler(ignoreCancelled=true) public void fall(EntityDamageEvent e){if(!(e.getEntity() instanceof Player p)||e.getCause()!=EntityDamageEvent.DamageCause.FALL)return;if(on("detections.movement.no-fall.enabled")&&p.getFallDistance()>=plugin.getConfig().getDouble("detections.movement.no-fall.min-fall-distance",5.0)&&e.getFinalDamage()<=0.01)flag(p,"NoFall",1.0,"fall distance="+p.getFallDistance()+", final damage="+e.getFinalDamage());}

    @EventHandler(ignoreCancelled=true) public void combat(EntityDamageByEntityEvent e){if(!(e.getDamager() instanceof Player p)||!(e.getEntity() instanceof LivingEntity target)||!active(p)||!on("detections.combat.enabled"))return;double distance=p.getEyeLocation().distance(target.getLocation().add(0,Math.min(target.getHeight()*.65,1.2),0));if(on("detections.combat.reach.enabled")&&distance>plugin.getConfig().getDouble("detections.combat.reach.max-distance",3.65)){flag(p,"Reach",plugin.getConfig().getDouble("detections.combat.reach.vl",3),String.format(Locale.US,"eye-to-target=%.3f",distance));}
        long now=System.currentTimeMillis();UUID id=p.getUniqueId();if(now-hitWindow.getOrDefault(id,now)>1000){int count=combatHits.getOrDefault(id,0);if(on("detections.combat.autoclicker.enabled")&&count>plugin.getConfig().getInt("detections.combat.autoclicker.cps-limit",16))flag(p,"AutoClicker",1.0,"combat hit events in one-second window="+count);combatHits.put(id,0);hitWindow.put(id,now);}combatHits.merge(id,1,Integer::sum);
        UUID old=lastTarget.put(id,target.getUniqueId());if(old!=null&&!old.equals(target.getUniqueId())){int switches=targetSwitches.merge(id,1,Integer::sum);if(on("detections.combat.kill-aura.enabled")&&switches>=plugin.getConfig().getInt("detections.combat.kill-aura.rapid-target-switches",8)){flag(p,"KillAura",1.0,"rapid target changes="+switches);targetSwitches.put(id,0);}}else targetSwitches.merge(id,0,Integer::sum);
    }

    @EventHandler(ignoreCancelled=true) public void mine(BlockBreakEvent e){Player p=e.getPlayer();if(!active(p))return;UUID id=p.getUniqueId();long now=System.currentTimeMillis();String type=e.getBlock().getType().name();boolean ore=type.endsWith("_ORE")||type.equals("ANCIENT_DEBRIS");if(on("detections.xray.enabled")){if(now-oreWindow.getOrDefault(id,now)>60000){mined.put(id,0);ores.put(id,0);oreWindow.put(id,now);}mined.merge(id,1,Integer::sum);if(ore)ores.merge(id,1,Integer::sum);int total=mined.get(id),found=ores.get(id);if(total>=plugin.getConfig().getInt("detections.xray.min-blocks",80)&&found/(double)total>plugin.getConfig().getDouble("detections.xray.ore-ratio",.18)){flag(p,"Xray",1.0,"rolling mined blocks="+total+", ores="+found+", ratio="+String.format(Locale.US,"%.2f",found/(double)total));mined.put(id,0);ores.put(id,0);}}
        Long start=lastBreak.remove(id);if(start!=null&&now-start<plugin.getConfig().getLong("detections.world.fast-break.min-break-ms",90)&&on("detections.world.fast-break.enabled")){flag(p,"FastBreak",1.0,"block break elapsed="+(now-start)+"ms; hardness/tool context not fully observable");}
    }
    @EventHandler(ignoreCancelled=true) public void blockDamage(BlockDamageEvent e){lastBreak.put(e.getPlayer().getUniqueId(),System.currentTimeMillis());}
    @EventHandler(ignoreCancelled=true) public void place(BlockPlaceEvent e){Player p=e.getPlayer();if(!active(p))return;UUID id=p.getUniqueId();long now=System.currentTimeMillis();if(now-placeWindow.getOrDefault(id,now)>1000){int count=placeCount.getOrDefault(id,0);if(on("detections.world.suspicious-placement.enabled")&&count>plugin.getConfig().getInt("detections.world.suspicious-placement.max-placements-per-second",14))flag(p,"FastPlace",1,"placements per second="+count);placeCount.put(id,0);placeWindow.put(id,now);}placeCount.merge(id,1,Integer::sum);
        Block placed=e.getBlockPlaced();Location feet=p.getLocation().clone().subtract(0,1,0);if(placed.getY()<=feet.getBlockY()&&placed.getWorld().equals(p.getWorld())){int n=underPlaces.merge(id,1,Integer::sum);if(on("detections.world.scaffold.enabled")&&n>=plugin.getConfig().getInt("detections.world.scaffold.min-under-placements",7)){flag(p,"Scaffold",1.0,"repeated blocks placed beneath player="+n);underPlaces.put(id,0);}}else underPlaces.put(id,0);
    }
    @EventHandler(ignoreCancelled=true) public void inventory(InventoryClickEvent e){if(!(e.getWhoClicked() instanceof Player p)||!active(p)||!on("detections.inventory.enabled"))return;UUID id=p.getUniqueId();long now=System.currentTimeMillis();if(now-clickWindow.getOrDefault(id,now)>1000){int n=inventoryClicks.getOrDefault(id,0);if(n>plugin.getConfig().getInt("detections.inventory.max-clicks-per-second",35))flag(p,"InventoryAbuse",1,"inventory clicks per second="+n);inventoryClicks.put(id,0);clickWindow.put(id,now);}inventoryClicks.merge(id,1,Integer::sum);}
}
