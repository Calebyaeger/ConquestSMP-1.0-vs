package com.conquest.anticheat.command;

import com.conquest.anticheat.ConquestAntiCheat;
import org.bukkit.*;
import org.bukkit.command.*;
import org.bukkit.entity.Player;
import java.util.*;
import java.util.concurrent.CompletableFuture;

public final class CacCommand implements CommandExecutor, TabCompleter {
    private final ConquestAntiCheat plugin;
    public CacCommand(ConquestAntiCheat plugin){this.plugin=plugin;}
    private void msg(CommandSender s,String text){s.sendMessage(ChatColor.translateAlternateColorCodes('&',"&8[&cConquestAC&8] &7"+text));}
    private Player find(String name){return Bukkit.getPlayerExact(name);}
    @Override public boolean onCommand(CommandSender sender,Command command,String label,String[] a){if(a.length==0||a[0].equalsIgnoreCase("help")){msg(sender,"&c/cac alerts &7- toggle your alerts");msg(sender,"&c/cac check <player> &7- current violation profile");msg(sender,"&c/cac history <player> &7- stored evidence history");msg(sender,"&c/cac xray <player> &7- mining-analysis history");msg(sender,"&c/cac punish <player> <warn|kick|tempban> &7- staff-reviewed action");msg(sender,"&c/cac reload &7- reload configuration");msg(sender,"&c/cac info &7- plugin information");return true;}
        switch(a[0].toLowerCase(Locale.ROOT)){
            case "alerts"->{if(!(sender instanceof Player p)){msg(sender,"Only players can toggle personal alerts.");return true;}if(!p.hasPermission("conquestac.alerts")){msg(sender,"No permission.");return true;}boolean current=p.hasMetadata("cac_alerts_off");if(current){p.removeMetadata("cac_alerts_off",plugin);msg(sender,"Alerts enabled.");}else{p.setMetadata("cac_alerts_off",new org.bukkit.metadata.FixedMetadataValue(plugin,true));msg(sender,"Alerts disabled.");}return true;}
            case "check"->{if(!sender.hasPermission("conquestac.check")){msg(sender,"No permission.");return true;}if(a.length<2){msg(sender,"Usage: /cac check <player>");return true;}OfflinePlayer op=Bukkit.getOfflinePlayer(a[1]);msg(sender,"Profile for &f"+a[1]+"&7: UUID="+op.getUniqueId()+", current session VL="+String.format(Locale.US,"%.1f",plugin.getViolations(op.getUniqueId())));return true;}
            case "history","xray"->{if(!sender.hasPermission(a[0].equalsIgnoreCase("xray")?"conquestac.xray":"conquestac.history")){msg(sender,"No permission.");return true;}if(a.length<2){msg(sender,"Usage: /cac "+a[0]+" <player>");return true;}OfflinePlayer op=Bukkit.getOfflinePlayer(a[1]);CompletableFuture<List<String>> future=plugin.database().history(op.getUniqueId(),30);future.thenAccept(rows->Bukkit.getScheduler().runTask(plugin,()->{msg(sender,"Evidence history for &f"+a[1]+"&7 (latest 30):");int shown=0;for(String row:rows){if(a[0].equalsIgnoreCase("xray")&&!row.contains("Xray"))continue;msg(sender,row);shown++;}if(shown==0)msg(sender,"No matching evidence records found.");}));return true;}
            case "reload"->{if(!sender.hasPermission("conquestac.reload")){msg(sender,"No permission.");return true;}plugin.reloadPlugin();msg(sender,"Configuration reloaded.");return true;}
            case "info"->{msg(sender,"&fConquest SMP Anti-Cheat &71.0.0 | Paper 1.21.11");msg(sender,"&7SQLite evidence storage | Staff-reviewed punishments: "+plugin.getConfig().getBoolean("punishments.staff-review-required",true));return true;}
            case "punish"->{if(!sender.hasPermission("conquestac.staff")){msg(sender,"No permission.");return true;}if(a.length<3){msg(sender,"Usage: /cac punish <player> <warn|kick|tempban>");return true;}Player target=find(a[1]);if(target==null){msg(sender,"Player must be online.");return true;}switch(a[2].toLowerCase(Locale.ROOT)){case "warn"->target.sendMessage(ChatColor.RED+"A staff member has issued an anti-cheat warning. Please contact staff if this is unexpected.");case "kick"->target.kickPlayer("Kicked by staff after ConquestAC review.");case "tempban"->{long mins=plugin.getConfig().getLong("punishments.temporary-ban-minutes",30);Bukkit.getBanList(BanList.Type.NAME).addBan(target.getName(),"Staff-reviewed ConquestAC temporary ban",new Date(System.currentTimeMillis()+mins*60_000L),sender.getName());target.kickPlayer("Temporary ban issued by staff.");}default->{msg(sender,"Action must be warn, kick, or tempban.");return true;}}msg(sender,"Staff action applied to "+target.getName()+".");return true;}
            default->{msg(sender,"Unknown subcommand. Use /cac help.");return true;}
        }
    }
    @Override public List<String> onTabComplete(CommandSender s,Command c,String a,String[] args){if(args.length==1)return List.of("help","alerts","check","history","xray","reload","info","punish").stream().filter(x->x.startsWith(args[0].toLowerCase(Locale.ROOT))).toList();if(args.length==2&&List.of("check","history","xray","punish").contains(args[0].toLowerCase(Locale.ROOT)))return Bukkit.getOnlinePlayers().stream().map(Player::getName).filter(n->n.toLowerCase(Locale.ROOT).startsWith(args[1].toLowerCase(Locale.ROOT))).toList();if(args.length==3&&args[0].equalsIgnoreCase("punish"))return List.of("warn","kick","tempban");return Collections.emptyList();}
}
