package com.conquest.anticheat;

import com.conquest.anticheat.command.CacCommand;
import com.conquest.anticheat.db.ViolationDatabase;
import com.conquest.anticheat.detect.DetectionManager;
import com.conquest.anticheat.model.Violation;
import com.conquest.anticheat.util.Webhook;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import java.io.File;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public final class ConquestAntiCheat extends JavaPlugin {
    private ViolationDatabase database;
    private final Map<UUID,Double> violations=new ConcurrentHashMap<>();
    private final Map<UUID,Long> lastViolation=new ConcurrentHashMap<>();
    @Override public void onEnable(){saveDefaultConfig();try{File db=new File(getDataFolder(),getConfig().getString("database.file","violations.db"));database=new ViolationDatabase(db);database.initialize();}catch(Exception ex){getLogger().severe("Could not initialize SQLite: "+ex.getMessage());getServer().getPluginManager().disablePlugin(this);return;}
        getServer().getPluginManager().registerEvents(new DetectionManager(this),this);Objects.requireNonNull(getCommand("cac")).setExecutor(new CacCommand(this));Objects.requireNonNull(getCommand("cac")).setTabCompleter(new CacCommand(this));getLogger().info("Conquest SMP Anti-Cheat enabled. Evidence-based checks active.");
    }
    @Override public void onDisable(){if(database!=null)database.close();}
    public ViolationDatabase database(){return database;}
    public double getViolations(UUID id){return violations.getOrDefault(id,0d);}
    public void flag(Player player,String check,double amount,String evidence){UUID id=player.getUniqueId();long now=System.currentTimeMillis();long decay=getConfig().getLong("settings.violation-decay-minutes",30)*60_000L;if(now-lastViolation.getOrDefault(id,now)<decay)violations.merge(id,amount,Double::sum);else violations.put(id,amount);lastViolation.put(id,now);
        Violation v=new Violation(id,player.getName(),check,amount,evidence,Instant.now());database.insert(v);String message=ChatColor.translateAlternateColorCodes('&',getConfig().getString("settings.alert-prefix","&8[&cConquestAC&8] "))+ChatColor.RED+player.getName()+ChatColor.GRAY+" flagged "+ChatColor.YELLOW+check+ChatColor.GRAY+" (VL "+String.format(Locale.US,"%.1f",getViolations(id))+") "+ChatColor.DARK_GRAY+evidence;
        if(getConfig().getBoolean("alerts.enabled",true)){if(getConfig().getBoolean("alerts.console",true))getLogger().warning(ChatColor.stripColor(message));for(Player staff:Bukkit.getOnlinePlayers())if(staff.hasPermission(getConfig().getString("alerts.permission","conquestac.alerts"))&&!staff.hasMetadata("cac_alerts_off"))staff.sendMessage(message);if(getConfig().getBoolean("alerts.webhook.enabled",false))Webhook.send(getConfig().getString("alerts.webhook.url",""),ChatColor.stripColor(message));}
        if(!getConfig().getBoolean("punishments.enabled",true)||getConfig().getBoolean("punishments.staff-review-required",true))return;double vl=getViolations(id);if(vl>=getConfig().getDouble("punishments.thresholds.temporary-ban",30)){long mins=getConfig().getLong("punishments.temporary-ban-minutes",30);Bukkit.getBanList(org.bukkit.BanList.Type.NAME).addBan(player.getName(),"ConquestAC: automated temporary review threshold",new Date(now+mins*60_000L),"ConquestAC");player.kickPlayer("Temporary ban: anti-cheat threshold reached. Contact staff for review.");}else if(vl>=getConfig().getDouble("punishments.thresholds.kick",16))player.kickPlayer("ConquestAC: suspicious activity detected. Contact staff.");else if(vl>=getConfig().getDouble("punishments.thresholds.warning",8))player.sendMessage(ChatColor.RED+"ConquestAC: suspicious activity detected. Please play normally.");
    }
    public void reloadPlugin(){reloadConfig();}
}
